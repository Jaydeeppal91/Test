<?php
{
$Name=$_POST['sname'];
$Address=$_POST['add'];
$Contact No=$_POST['Mo'];
$Email-Id=$_POST['id'];
{
print "<br> $Name, <br> $Address, <br> $Contact No, <br> $Email-Id";
}
}
?>